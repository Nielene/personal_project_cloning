*…or create a new repository on the command line*
echo "# nodejs_imports_exports" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/Nielene/nodejs_imports_exports.git
git push -u origin master

*…or push an existing repository from the command line*
git remote add origin https://github.com/Nielene/nodejs_imports_exports.git
git push -u origin master

//------------------
Exercise:
https://github.com/joinpursuit/Pursuit-Core-Web/blob/master/node/modules/exercise.md

Project:
https://github.com/joinpursuit/Pursuit-Core-Web/blob/master/node/modules/project.md

Calendar:
https://canvas.instructure.com/calendar#view_name=month&view_start=2018-11-29

//--------------------
