const myModules = require("./usefulArrayMethods.js");

console.log(myModules.first("hello"));
