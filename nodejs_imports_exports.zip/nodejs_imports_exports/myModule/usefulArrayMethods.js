module.exports = {

  first(arr) {return arr[0]},
  tail(arr) {return arr.slice(1)},
  last(arr) {return arr[arr.length-1]},
  sum(arr) {return arr.return((sum, curr) => sum + curr)}







}
